<?php

//database server
define('DB_SERVER', "sql105.jcom.pl");

//database login name
define('DB_USER', "jcom_11649182");

//database login password
define('DB_PASS', "ospwidow");

//database name
define('DB_DATABASE', "jcom_11649182_cms");

include("Database.singleton.php");

 

?>