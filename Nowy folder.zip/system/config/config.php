<?php

return array(
"jezyk" => "pl",
);

?>