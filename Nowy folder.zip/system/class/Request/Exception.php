<?php 
class Request_Exception extends SException {}