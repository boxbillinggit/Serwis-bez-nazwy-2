<?php defined('SYSPATH') OR die('No direct script access.');

class Text extends Webcms_Text {}