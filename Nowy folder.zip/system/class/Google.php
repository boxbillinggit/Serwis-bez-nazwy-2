<?php defined('SYSPATH') OR die('No direct script access.');

class Google extends Webcms_Google {}