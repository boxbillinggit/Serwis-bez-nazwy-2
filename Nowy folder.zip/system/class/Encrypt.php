<?php defined('SYSPATH') or die('No direct script access.');

class Encrypt extends Webcms_Encrypt {}
