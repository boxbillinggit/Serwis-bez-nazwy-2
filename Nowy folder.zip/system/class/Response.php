<?php defined('SYSPATH') OR die('No direct script access.');

class Response extends Webcms_Response {}