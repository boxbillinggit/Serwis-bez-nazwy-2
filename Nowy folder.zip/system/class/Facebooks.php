<?php defined('SYSPATH') OR die('No direct script access.');

class Facebooks extends Webcms_Facebooks {}