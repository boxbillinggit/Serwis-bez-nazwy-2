<?php defined('SYSPATH') OR die('No direct script access.');

class Webcms_Jezyk {
	
	public static function lang() {
	return Config::get("config")->jezyk;	
	}
	
	public static function laduj($name) {
	
	$wybierz = DB::query(Database::SELECT, 'SELECT * FROM tlumaczenia WHERE name="'.$name.'" AND active = 1')->execute()->as_array();
	
	$db = DB::query(Database::SELECT, 'SELECT * FROM tlumaczenia_data WHERE lang_id='.$wybierz[0]['id'])->execute()->as_array();
	foreach($db as $row) {
		$jezyk[$row['klucz']] = $row['wartosc'];
	}

	return $jezyk;
		
	}
	
	public static function get($name) {
	
		$tlumaczenie = Jezyk::laduj(Jezyk::lang());
				
		return $tlumaczenie[$name];
		
	}
	
}

?>