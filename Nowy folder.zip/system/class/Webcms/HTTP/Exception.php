<?php 
abstract class Webcms_HTTP_Exception extends SException {

	public static function factory($code, $message = NULL, array $variables = NULL, $previous = NULL)
	{
		$class = 'HTTP_Exception_'.$code;
		
		return new $class($message, $variables, $previous);
	}

	protected $_code = 0;

	protected $_request;

	public function __construct($message = NULL, array $variables = NULL, $previous = NULL)
	{
		//parent::__construct($message, $variables, $this->_code, $previous);
	}
 
	public function request(Request $request = NULL)
	{
		if ($request === NULL)
			return $this->_request;
		
		$this->_request = $request;

		return $this;
	}

	public function get_response()
	{
		return SException::response($this);
	}

}