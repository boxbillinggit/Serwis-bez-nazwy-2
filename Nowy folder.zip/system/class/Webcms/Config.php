<?php defined('SYSPATH') or die('No direct script access.');

class Webcms_Config {

	protected static $_instance;

	public static function instance()
	{
		if (self::$_instance === NULL)
		{
			self::$_instance = new self;
		}

		return self::$_instance;
	}

	protected $_readers = array();

	public function attach(Webcms_Config_Reader $reader, $first = TRUE)
	{
		if ($first === TRUE)
		{
			// Place the log reader at the top of the stack
			array_unshift($this->_readers, $reader);
		}
		else
		{
			// Place the reader at the bottom of the stack
			$this->_readers[] = $reader;
		}

		return $this;
	}

	public function detach(Webcms_Config_Reader $reader)
	{
		if (($key = array_search($reader, $this->_readers)))
		{
			// Remove the writer
			unset($this->_readers[$key]);
		}

		return $this;
	}

	public function load($group)
	{
		foreach ($this->_readers as $reader)
		{
			if ($config = $reader->load($group))
			{
				// Found a reader for this configuration group
				return $config;
			}
		}

		// Reset the iterator
		reset($this->_readers);

		if ( ! is_object($config = current($this->_readers)))
		{
			throw new Webcms_Exception('No configuration readers attached');
		}

		// Load the reader as an empty array
		return $config->load($group, array());
	}

	public function copy($group)
	{
		// Load the configuration group
		$config = $this->load($group);

		foreach ($this->_readers as $reader)
		{
			if ($config instanceof $reader)
			{
				// Do not copy the config to the same group
				continue;
			}

			// Load the configuration object
			$object = $reader->load($group, array());

			foreach ($config as $key => $value)
			{
				// Copy each value in the config
				$object->offsetSet($key, $value);
			}
		}

		return $this;
	}

	final private function __construct()
	{
		// Enforce singleton behavior
	}

	final private function __clone()
	{
		// Enforce singleton behavior
	}
	
	public static function get($name) {
	
	$config = (object) Webcms::load(SYSPATH.'config/'.$name.EXT);	
	return $config;
		
	}
	
}
