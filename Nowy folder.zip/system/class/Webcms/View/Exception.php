<?php defined('SYSPATH') or die('No direct script access.');

class Webcms_View_Exception extends Webcms_Exception {  }