<?php defined('SYSPATH') OR die('No direct script access.');

class Jezyk extends Webcms_Jezyk {}

?>