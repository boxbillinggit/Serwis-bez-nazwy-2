<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Controller extends Webcms_Controller {}