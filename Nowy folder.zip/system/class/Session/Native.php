<?php defined('SYSPATH') or die('No direct script access.');

class Session_Native extends Webcms_Session_Native {}
