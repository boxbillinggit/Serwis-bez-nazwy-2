<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception extends Webcms_HTTP_Exception {}