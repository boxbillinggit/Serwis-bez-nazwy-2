<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Header extends Webcms_HTTP_Header {}