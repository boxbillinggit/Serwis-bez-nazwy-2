<?php defined('SYSPATH') or die('No direct script access.');

class URL extends Webcms_URL {}