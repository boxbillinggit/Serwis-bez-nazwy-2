<?php


Route::set('dokumentacja', 'dokumentacja(/<action>)')->defaults(array(
			'controller' => 'dokumentacja',
			'action'     => 'index',
		));


?>