<?php defined('SYSPATH') or die('No direct access allowed.');

class Auth_File extends Webcms_Auth_File { }