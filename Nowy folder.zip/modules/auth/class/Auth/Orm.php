<?php defined('SYSPATH') OR die('No direct access allowed.');

class Auth_ORM extends Webcms_Auth_ORM { }