<?php defined('SYSPATH') or die('No direct access allowed.');

abstract class Auth extends Webcms_Auth { }