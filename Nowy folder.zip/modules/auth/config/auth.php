<?php defined('SYSPATH') or die('No direct access allowed.');

return array(

	'driver'       => 'Orm',
	'hash_method'  => 'md5',
	'hash_key'     => 'Webcms',
	'lifetime'     => 1209600,
	'session_key'  => 'Webcms_user',
	'users' => array(
		// 'admin' => '83bae67ce5d4ffe7c750bbc65151d9f4',
	),

);