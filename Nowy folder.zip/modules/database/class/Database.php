<?php defined('SYSPATH') or die('No direct script access.');

abstract class Database extends Webcms_Database {}
