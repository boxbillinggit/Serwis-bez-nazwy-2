<?php defined('SYSPATH') or die('No direct script access.');

class Database_MySQL extends Webcms_Database_MySQL {}
