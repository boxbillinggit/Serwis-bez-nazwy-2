<?php defined('SYSPATH') or die('No direct script access.');

class Database_Expression extends Webcms_Database_Expression {}
