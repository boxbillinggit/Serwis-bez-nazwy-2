<?php defined('SYSPATH') or die('No direct script access.');

abstract class Database_Query_Builder_Where extends Webcms_Database_Query_Builder_Where {}
