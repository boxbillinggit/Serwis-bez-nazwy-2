<?php defined('SYSPATH') or die('No direct script access.');

class Database_Query_Builder_Update extends Webcms_Database_Query_Builder_Update {}
