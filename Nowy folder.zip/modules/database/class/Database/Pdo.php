<?php defined('SYSPATH') or die('No direct script access.');

class Database_PDO extends Webcms_Database_PDO {}
