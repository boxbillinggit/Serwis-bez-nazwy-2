<?php defined('SYSPATH') or die('No direct script access.');

class Database_Query extends Webcms_Database_Query {}
