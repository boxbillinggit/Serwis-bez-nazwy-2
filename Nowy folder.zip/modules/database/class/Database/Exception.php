<?php defined('SYSPATH') or die('No direct script access.');

class Database_Exception extends Webcms_Database_Exception {}
