<?php defined('SYSPATH') or die('No direct script access.');

/**

 * Database exceptions.

 *

 * @package    Database

 * @author     Webcms Team

 * @copyright  (c) 2009 Webcms Team

 * @license    http://Webcmsphp.com/license

 */

class Webcms_Database_Exception extends Webcms_Exception {}

