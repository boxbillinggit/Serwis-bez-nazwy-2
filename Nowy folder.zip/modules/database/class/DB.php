<?php defined('SYSPATH') or die('No direct script access.');

class DB extends Webcms_DB {}
