<?php defined('SYSPATH') or die('No direct script access.');

class Session_Database extends Webcms_Session_Database {}
