<div class="row-fluid">
<div class="span12" id="user-list">
							<h3 class="heading">Kalendarz</h3>
								<ul class="nav nav-tabs">
									<li class="active"><a data-toggle="tab" href="#calendar">Wydarzenia</a></li>
                                    <li class=""><a data-toggle="tab" href="#add_calendar">Dodaj Wydarzenie</a></li>
								</ul>
<div class="tab-content">
<div class="tab-pane active" id="calendar">

<table class="table">
										<thead>
											<tr>
                                            <th style="width:40px;"></th>
												<th>Id</th>
												<th>Start</th>
												<th>Koniec</th>
                                                <th>Tytuł</th>
                                                <th>Opis</th>
                                                <th>Piorytet</th>
                                                <th>Frecuency</th>
												<th></th>
											</tr>
										</thead>
										<tbody id="sortable">


										<?php
										$i=1;
										 foreach($calendar as $cal) {
											
											echo '<tr>
                                            <td style="width:40px;"></td>
												<td>'.$cal->id.'</td>
												<td>'.$cal->startDate.'</td>
												<td>'.$cal->endDate.'</td>
                                                <td>'.$cal->title.'</td>
                                                <td>'.$cal->description.'</td>
                                                <td>'.$cal->priority.'</td>
                                                <td>'.$cal->frecuency.'</td>
												<td><a title="Delete" href="#demoModal'.$i.'" data-backdrop="static" data-toggle="modal" oldtitle="New messages" aria-describedby="ui-tooltip-17"><i class="icon-trash"></i></a></td>
											</tr>';
											
											echo '<!-- USUN modal -->
								<div class="modal fade hide modal-info" id="demoModal'.$i.'">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">×</button>
										<h3>Informacja!!</h3>
									</div>
									<div class="modal-body">
										<p>Potwierdzenie Usunięcia: <b>'.$cal->title.'</b></p>
										<p>Czy jesteś pewien że chcesz usunąc Wydarzenie ??</p>
									</div>
									<div class="modal-footer">
										<a href="#" class="btn btn-alt" data-dismiss="modal">Anuluj Usuwanie</a>
										<a href="/admin/calendar_delete/'.$cal->id.'" class="btn btn-alt">Potwierdzam Usunięcie</a>
									</div>
								</div>
								<!-- /USUN modal -->';
											$i++;
										} ?>


										</tbody>
                                        </table>

</div>

<div class="tab-pane" id="add_calendar">
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
  <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" src="http://code.jquery.com/ui/1.10.2/jquery-ui.min.js"></script>

<script>
 $(document).ready(function() {
	  $("#startDate" ).datetimepicker({
		  showHour: true,
    	  showMinute: true,
		  dateFormat: 'yy-mm-dd'
		  });
	 					
						
 						$('#endDate').datepicker({
							showHour: false,
							showMinute: false,
							showTime: false,	
							dateFormat: 'yy-mm-dd'					
						});
						
						
 });
</script>

<form action="/admin/calendar_add" class="form-horizontal" method="POST">
         <fieldset>
         <div class="control-group">
           <label class="control-label" for="input">Start Data</label>
           <div class="controls">
              <input class="input-xxlarge" id="startDate" name="startDate" type="text">
              <p class="help-block">np. 2013-03-17 15:20:00</p>
           </div>
         </div>
                                                                                            
         <div class="control-group">
           <label class="control-label" for="input">Koniec Data</label>
             <div class="controls">
                 <input class="input-xxlarge" name="endDate" id="endDate" type="text">
                 <p class="help-block">np. 2013-02-01</p>
             </div>
         </div>
         
         <div class="control-group">
           <label class="control-label" for="input">Tytuł</label>
             <div class="controls">
                 <input class="input-xxlarge" name="title" id="title" type="text">
             </div>
         </div>
                                                                         
         <div class="control-group">
           <div class="controls">
             <textarea  id="wysiwg_full" class="wysiwyg" name="description" placeholder="Wprowadź Opis" rows="8"></textarea>
           </div>
         </div>
         
         <div class="control-group">
           <label class="control-label" for="input">Priority</label>
             <div class="controls">
                 <select name="priority">
                 	<option value="1">Low</option>
                    <option value="2">Medium</option>
                    <option value="3">Urgent</option>
                 </select>
             </div>
         </div>
         
         <div class="control-group">
           <label class="control-label" for="input">Frecuency</label>
             <div class="controls">
                 <select name="frecuency">
                 	<option value="1">Daily</option>
                    <option value="2">Weekly</option>
                    <option value="3">Monthly</option>
                    <option value="4">Yearly</option>
                 </select>
             </div>
         </div>
      
                                                                                            
         <div class="form-actions">
            <button class="btn btn-alt btn-large btn-primary" type="submit">Dodaj Wydarzenie</button>
         </div>
         </fieldset>
</form>

</div>


</div>
</div>
</div>