					<div class="row-fluid">
<article class="span12 data-block nested">
						<div class="data-container">
							<header>
								<h2>Galeria</h2>
							</header>
							<section>
                            <script src="http://www.abjlanette.pl/web/view/admin/js/jquery.min.js"></script>
                            <script>
								$(document).ready(function(e) {
                                    
									$("#submit").submit(function() {
										
										$.post("/admin/galkatadd", { title: $("#input_title").val() }).done(function(data) {
										  $("#info").load("/admin/get_galkat");
										});
										return false;
									});
									
									$("#info").load("/admin/get_galkat", function(response, status, xhr) {
										  if (status == "error") {
											var msg = "Sorry but there was an error: ";
											$("#info").html(msg + xhr.status + " " + xhr.statusText);
										  }
									});
									
                                });
							</script>
							
                                            
                            <link rel="stylesheet" href="<?php echo $uri; ?>css/plugins/jquery.plupload.queue.css">
							<link rel="stylesheet" href="<?php echo $uri; ?>css/plugins/jquery.ui.plupload.css">
                                                                                        <form action="#" class="form-horizontal" enctype="multipart/form-data" id="submit" method="POST">
                                                                                        <fieldset>
                                                                                            <legend>Dodaj Kategorie</legend>
                                                                                            <div class="control-group">
                                                                                                <label class="control-label" for="input">Tytuł</label>
                                                                                                <div class="controls">
                                                                                                    <input id="input_title" class="input-xxlarge" name="title" type="text">
                                                                                                </div>
                                                                                            </div>


      																						<div class="form-actions">
                                                                                                <button class="btn btn-alt btn-large btn-primary" type="submit" id="add">Dodaj</button>
                                                                                            </div>	
                                                                                            </fieldset>
                                                                                            </form>
                                            
                                              
                                              <div id="info"></div>
                                              
                                              
	</section>
						</div>
					</article>
                    