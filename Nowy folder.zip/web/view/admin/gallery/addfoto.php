<div class="row-fluid">
<article class="span12 data-block nested">
						<div class="data-container">
							<header>
								<h2>Galeria</h2>
							</header>
							<section>
          
     