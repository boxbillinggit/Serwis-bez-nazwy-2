<?php defined('SYSPATH') or die('No direct script access.');

return array(
	
	'default' => array(
		'support' => 'sylwiakowalska@abj.gliwice.pl',
		'webmaster' => 'webmaster@abjlanette.pl',
	)
);
