<?php defined('SYSPATH') or die('No direct script access.');

return array(
	
	'default' => array(
		'ga_username' => 'jnowakk11@gmail.com',
		'ga_password' => 'BV931Op1',
		'ga_page' => '67367832'
	)
);
