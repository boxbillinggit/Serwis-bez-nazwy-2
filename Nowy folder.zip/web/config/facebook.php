<?php defined('SYSPATH') or die('No direct script access.');

return array(
	
	'default' => array(
		'app_id' => '415814255162781',
		'app_secret' => '4963b677dfe0ef98a8c5e28412b8b654',
		'access_token' => 'AAAF6Lkz4tZA0BAGSZAuQ5zjRLN6JczvW0oPcqtvQZB5clmazpQlvHSeZBV4ZBLaDtgIwHLd0L2ZBa2oHPFEhZCHP425hTBCbQfnNcFyYC0IsPwoV2uGV1gV'
	)
);
