<?php 
class Controller_Admin_admin extends Controller {

	public $template = 'admin/page';

	public function __construct() {
	$this->session = Session::instance();
    $this->auth = Auth::instance();
	$this->fb = Facebooks::instance();
	Webcms::load(SYSPATH.'class/Constant.php');	
	}

	public function before()
    {
		$this->log = new Logs ( $_SERVER['DOCUMENT_ROOT']."/system/logs/log.csv" ,';' );
    }

public function action_index() {
	if ($this->auth->logged_in()) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	$this->template->content = 'Super Wypasiony content ';
	echo $this->template;
	} else {
	$this->template = View::factory('admin/login');
	$this->template->title = 'Panel Administracyjny';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	echo $this->template;
	}
}

public function action_gallery() 
{ 
	if ($this->auth->logged_in())
	{
		$this->template = View::factory('admin/page');
		$this->template->title = 'Panel Administracyjny';
		$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
		$this->template->users = Auth::instance()->get_user();
		$this->template->content = View::factory('admin/podstrony/gallery');
		
		if (!empty($_FILES))
		{
			$filename = Upload::save($_FILES, APPPATH . 'uploads/gallery');
						
			DB::query(Database::INSERT, DB::insert('galeria', array('name'))->values(array($filename)))->execute();			
			
		}
		
		$query = DB::query(Database::SELECT, 'SELECT * FROM galeria')->execute()->as_array();		
		
		$this->template->content->zdjecia = $query;
		
		echo $this->template;
		
	}
	else
	{
		$this->template = View::factory('admin/login');
		$this->template->title = 'Panel Administracyjny';
		$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
		echo $this->template;
	}
}

public function action_gallery_thumb($id = null, $param2 = null) 
{ 	
	if ($this->auth->logged_in())
	{
		/*		
		$this->template = View::factory('admin/page');
		$this->template->title = 'Panel Administracyjny';
		$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
		$this->template->users = Auth::instance()->get_user();
		$this->template->content = View::factory('admin/podstrony/gallery');
		
		if (!empty($_FILES))
		{
			$filename = Upload::save($_FILES, APPPATH . 'uploads/gallery');
			
			DB::query(Database::INSERT, DB::insert('galeria', array('name'))->values(array($filename)))->execute();			
			
		}
		
		$query = DB::query(Database::SELECT, 'SELECT * FROM galeria')->execute()->as_array();		
		
		$this->template->content->zdjecia = $query;
		
		echo $this->template;
		*/
		pr(Request::instance()->param('id'));
		pr(Request::instance()->param('param2'));
	}
	else
	{
		$this->template = View::factory('admin/login');
		$this->template->title = 'Panel Administracyjny';
		$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
		echo $this->template;
	}
}

public function action_podstrony() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Pod Strony';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT *, cms.id as id_cms FROM  `cms` LEFT JOIN  `menu` ON cms.seo = menu.link')->execute()->as_array();
	$menii = DB::query(Database::SELECT, 'SELECT * FROM menu WHERE sub_id=0 AND top=1')->execute()->as_array();
	$this->template->content = View::factory('admin/podstrony/index')->bind('podstrona',$query)->bind('menn',$menii);
	
	
	//KONCZE LADOWAĆ
	echo $this->template;
	$data = Request::current()->post();
	if(empty($data)) {} else {	
	$seo = str_replace(" ","_",$data['seo']);
	DB::query(Database::INSERT, DB::insert('menu', array('name','link','top','sub_id'))->values(array($data['title'],$seo,0,$data['sub_id'])))->execute();
	unset($data['sub_id']);
	DB::query(Database::INSERT, DB::insert('cms', array_keys($data))->values(array_values($data)))->execute();
	$this->log->info('Dodano Nową Podstrone O Tytule: '.$data['title']);
		Request::instance()->redirect("/admin/podstrony");
	}
	 
	
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_podstrony_edit($id) {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Pod Strony - Edycja';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT * FROM cms WHERE id="'.$id.'"')->as_object()->execute()->as_array();
	$query_seo = DB::query(Database::SELECT, 'SELECT * FROM menu WHERE link="'.$query[0]->seo.'"')->as_object()->execute()->as_array();
	$this->template->content = View::factory('admin/podstrony/edit')->bind('podstrona',$query)->bind('seo_id',$query_seo);
	
	//KONCZE LADOWAĆ
	echo $this->template;
	$data = Request::current()->post();
	if(empty($data)) {} else {
		DB::update('cms')->set(array('title' => $data['title'] ,  'text' => $data['text'] ,  'seo' => $data['seo'], 'comments_on_arts' => $data['comments'], 'rate_on_arts' => $data['rate'], 'logo' => $data['logo'] ))->where('id', '=', $id)->execute();
		$this->log->debug("Wyedytowano Wpis W Podstronach: <b>{$data['title']}</b>",'Podstrona');
		Request::instance()->redirect("/admin/podstrony_edit/".$id);
	}
	 
	
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_podstrony_ajax() {
$kolejnosc = 1;
foreach($_POST['list'] as $klucz => $pozycja) {
	DB::update('cms')->set(array('position' => $kolejnosc))->where('id', '=', $pozycja)->execute();
	$cms = DB::query(Database::SELECT, 'SELECT * FROM cms WHERE id="'.$pozycja.'" AND seo LIKE \'%/show/%\';')->execute()->as_array();
	$seo = @$cms[0]['seo'];
	DB::update('menu')->set(array('position' => $kolejnosc))->where('link', '=', $seo)->execute();
	$kolejnosc = $kolejnosc +1;
}
die();
}

public function action_podstrony_delete($id) {
$this->log->warning('Usunięto Podstrone o id: '.$id);
DB::delete('cms')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/podstrony");	
}
################################################ UŻYTKOWNICY
public function action_users() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Użytkownicy';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT * FROM users')->execute()->as_array();
	$role = DB::query(Database::SELECT, 'SELECT * FROM roles')->execute()->as_array();
	$this->template->content = View::factory('admin/users/index')->bind('users',$query)->bind('role',$role);
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_users_add() {
	if ($this->auth->logged_in('admin')) {
			$client = ORM::factory('user');
            $client->email = $_POST['email'];
            $client->username = $_POST['username'];
            $client->password = $_POST['password'];
            $client->save();
			foreach($_POST['role'] as $rola) {
			$role = ORM::factory('role',$rola);
			$client->add('roles',$role);
			$client->save();
			}
			Request::instance()->redirect("/admin/users");
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_users_role_add() {
	if ($this->auth->logged_in('admin')) {
			$role = ORM::factory('role');
			$role->name = $_POST['name']; 
			$role->description = $_POST['description'];
			$role->save();
			Request::instance()->redirect("/admin/users");
	} else {
		Request::instance()->redirect("/admin");
	} 
	
}

public function action_users_edit($id) {
	if ($this->auth->logged_in('admin')) {
			if(empty($id)) {} else {
				$this->template = View::factory('admin/page');
				$this->template->title = 'Panel Administracyjny - Użytkownicy - Edycja Użytkownika o ID : '.$id;
				$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
				$this->template->users = Auth::instance()->get_user();
					$query = DB::query(Database::SELECT, 'SELECT * FROM users WHERE id='.$id)->execute()->as_array();
					$role = DB::query(Database::SELECT, 'SELECT * FROM roles')->execute()->as_array();
					$role_users = DB::query(Database::SELECT, 'SELECT * FROM roles_users WHERE user_id='.$id)->execute()->as_array();
				$this->template->content = View::factory('admin/users/form')->bind('role',$role)->bind('users',$query)->bind('role_user',$role_users);
				echo $this->template;
				
				$data = Request::current()->post();
				if(empty($data)) {} else {
					$haslo = Auth::hash($_POST['password']);
					DB::update('users')->set(array('email' => $_POST['email'],'username' => $_POST['username'],'password'=> $haslo))->where('id', '=', $id)->execute();
					Request::instance()->redirect("/admin/logout");
				}
			}
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_users_role_del($id) {
$this->log->warning('Usunięto Role o id: '.$id);
DB::delete('roles')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/users");		
}

public function action_users_del($id) {
$this->log->warning('Usunięto Użytkownika o id: '.$id);
$this->log->warning('Usunięto Role Użytkownika o id: '.$id);
DB::delete('roles_users')->where('user_id', '=', $id)->execute();
DB::delete('users')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/users");		
}

################################################ KONIEC

################################################ AKTUALNOSCI

public function action_news() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Aktualności';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	    $news = DB::query(Database::SELECT, 'SELECT * FROM news')->execute()->as_array();
		#$news_cat = DB::query(Database::SELECT, 'SELECT * FROM news_cat')->execute()->as_array();
	$this->template->content = View::factory('admin/news/index')->bind("news", $news)->bind("uri", $uris);
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_news_edit($id) {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Aktualności';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	    $news = DB::query(Database::SELECT, 'SELECT * FROM news WHERE id='.$id)->execute()->as_array();
		#$news_cat = DB::query(Database::SELECT, 'SELECT * FROM news_cat')->execute()->as_array();
	$this->template->content = View::factory('admin/news/edit')->bind("news", $news)->bind("uri", $uris);
	
	$data = Request::current()->post();
	if(empty($data)) {
		
	} else {
	    DB::update('news')->set(array('title' => $data['title'] ,  'text' => $data['text'] ,  'date' => $data['date'] ,  'autor' => $data['autor'] ,  'cat' => $data['cat'] ,  'active' => $data['active']))->where('id', '=', $id)->execute();
		$this->log->debug("Wyedytowano Wpis Aktualności: <b>{$data['title']}</b>",'Aktualnosci');
		Request::instance()->redirect("/admin/news");	
	}
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_news_add() {
	$data = Request::current()->post();
	if(empty($data)) {
		Request::instance()->redirect("/admin/news");
	} else {	
	$gal_cat = array("name" => $data['title'],"category_id"=>1);
	$filename = Upload::save($_FILES, APPPATH . 'uploads/news');
	$newss = array("title" => $data['title'],"text" => $data['text'],"date" => $data['date'],"autor" => $data['autor'],"foto" => $filename,"cat" => $data['cat'],"active" => $data['active']);
	//FB 

	//FB
	DB::query(Database::INSERT, DB::insert('news', array_keys($newss))->values(array_values($newss)))->execute();
	
		if($data['fb'] == 1) {
			
			$facebook = Facebooks::instance();
			$facebook->fb_update_status(array('message' => $data['text'], 'foto' => 'http://'.$_SERVER['HTTP_HOST'].URL::site('/web/uploads/news/thumbs/'.$filename)));  

		}

	//DB::query(Database::INSERT, DB::insert('galeria_categories', array_keys($gal_cat))->values(array_values($gal_cat)))->execute();
	$this->log->info('Dodano Nowy News: '.$data['title']);
		Request::instance()->redirect("/admin/news");
	}	
}

public function action_news_cat() {
	$data = Request::current()->post();
	if(empty($data)) {
		Request::instance()->redirect("/admin/news");
	} else {	
	DB::query(Database::INSERT, DB::insert('news_cat', array_keys($data))->values(array_values($data)))->execute();
	$this->log->info('Dodano Nową Kategorie: '.$data['name']);
		Request::instance()->redirect("/admin/news");
	}	
}

public function action_news_cat_delete($id) {
$this->log->warning('Usunięto Kategorie o id: '.$id);
DB::delete('news_cat')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/news");		
}

public function action_news_delete($id) {
$this->log->warning('Usunięto Aktualność o id: '.$id);
DB::delete('news')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/news");		
}

public function action_news_upload() {
//pr($_POST);
$next_id = DB::query(Database::SELECT, "SHOW TABLE STATUS LIKE 'galeria_categories'")->execute()->as_array();
Upload::upload_news(APPPATH . 'uploads/gallery',$next_id[0]['Auto_increment']);

		//	$filename = Upload::save($_FILES, APPPATH . 'uploads/gallery');
	
//pr($_FILES);	
}

################################################ KONIEC

public function action_wykresy() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Wykresy';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$this->template->content = View::factory('admin/wykresy/index')->bind("uri", $uris);
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_wykresy_linki() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Wykresy';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$this->template->content = View::factory('admin/wykresy/linki')->bind("uri", $uris);
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

############################################
#             PROMOCJE !!!                 #
############################################

public function action_promocje() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Promocje';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$promocje = DB::query(Database::SELECT, 'SELECT * FROM promocje')->execute()->as_array();
	$this->template->content = View::factory('admin/promocje/index')->bind("promocje", $promocje);
	
	$data = Request::current()->post();
	
	if(empty($data)) {} else {
		DB::query(Database::INSERT, DB::insert('promocje', array_keys($data))->values(array_values($data)))->execute();
		$this->log->debug("Wyedytowano Wpis Promocje Na Głównej: <b>{$data['title']}</b>",'Promocje');
		Request::instance()->redirect("/admin/promocje");
	}
	
	
	//KONCZE LADOWAĆ
	echo $this->template;	
	} else {
		Request::instance()->redirect("/admin");
	}
}


public function action_promocje_delete($id) {
$this->log->warning('Usunięto Promocje o id: '.$id);
DB::delete('promocje')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/promocje");	
}

############################################
#                KALENDARZ                 #
############################################

public function action_calendar() {
if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Kalendarz';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$calendar = DB::query(Database::SELECT, 'SELECT * FROM calendar')->as_object()->execute()->as_array();
	$this->template->content = View::factory('admin/calendar/index')->bind("calendar", $calendar);
	
	$data = Request::current()->post();
	
	if(empty($data)) {} else {
		DB::query(Database::INSERT, DB::insert('calendar', array_keys($data))->values(array_values($data)))->execute();
		$this->log->debug("Wyedytowano Wpis Do Kalendarza: <b>{$data['title']}</b>",'Calendar');
		Request::instance()->redirect("/admin/calendar");
	}
	
	
	//KONCZE LADOWAĆ
	echo $this->template;	
	} else {
		Request::instance()->redirect("/admin");
	}	
}

public function action_calendar_add() {
	$data = Request::current()->post();
	$dataf = $_FILES;
	if(empty($data)) {
		Request::instance()->redirect("/admin/calendar");
	} else {	
	DB::query(Database::INSERT, DB::insert('calendar', array_keys($data))->values(array_values($data)))->execute();
	$this->log->info('Dodano Nowe Wydarzenie: '.$data['title']);
	Request::instance()->redirect("/admin/calendar");
	}
}

public function action_calendar_delete($id) {
$this->log->warning('Usunięto Kalendarz o id: '.$id);
DB::delete('calendar')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/calendar");		
}

############################################
#              SLIDER I PART               #
############################################


public function action_slider() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Slider';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$slider = DB::query(Database::SELECT, 'SELECT * FROM slider')->execute()->as_array();
	$partnerzy = DB::query(Database::SELECT, 'SELECT * FROM partnerzy')->execute()->as_array();
	$this->template->content = View::factory('admin/sliders/slider')->bind("slider", $slider)->bind("partnerzy", $partnerzy);
	
	//KONCZE LADOWAĆ
	echo $this->template;	
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_slider_add() {
	$data = Request::current()->post();
	$dataf = $_FILES;
	if(empty($data)) {
		Request::instance()->redirect("/admin/news");
	} else {	
	$filename = Upload::save($_FILES, APPPATH . 'uploads/slider');
	$slider = array("src" => 'uploads/slider/'.$filename,"text" => $data['text'],"link" => $data['link'],"alt" => $data['alt']);
	DB::query(Database::INSERT, DB::insert('slider', array_keys($slider))->values(array_values($slider)))->execute();
	$this->log->info('Dodano Nowy Slider: '.$data['alt']);
	Request::instance()->redirect("/admin/slider");
	}
}

public function action_slider_delete($id) {
$this->log->warning('Usunięto Slider o id: '.$id);
DB::delete('slider')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/slider");		
}

public function action_partnerzy_add() {
	$data = Request::current()->post();
	$dataf = $_FILES;
	if(empty($data)) {
		Request::instance()->redirect("/admin/news");
	} else {	
	$filename = Upload::save($_FILES, APPPATH . 'uploads/partnerzy');
	$slider = array("foto" => 'uploads/partnerzy/'.$filename,"title" => $data['title'],"text" => $data['text'],"url" => $data['url'],"target"=>"");
	DB::query(Database::INSERT, DB::insert('partnerzy', array_keys($slider))->values(array_values($slider)))->execute();
	$this->log->info('Dodano Nowego Partnera: '.$data['title']);
	Request::instance()->redirect("/admin/slider");
	}
}

public function action_partnerzy_edit($id) {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Partnerzy - Edycja';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT * FROM partnerzy WHERE id="'.$id.'"')->as_object()->execute()->as_array();
	$this->template->content = View::factory('admin/sliders/partnerzy_edit')->bind('partnerzy',$query);
	echo $this->template;
	
	$data = Request::current()->post();
	
	if(empty($data)) {} else {
		DB::update('partnerzy')->set(array('title' => $data['title'] ,  'text' => $data['text'] ,  'link' => $data['link'] ))->where('id', '=', $id)->execute();
		$this->log->debug("Wyedytowano Wpis Partnerach Na Głównej: <b>{$data['title']}</b>",'Partnerzy Główna');
		Request::instance()->redirect("/admin/partnerzy_edit/".$id);
	}
	 
	
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_partnerzy_delete($id) {
$this->log->warning('Usunięto Partnera o id: '.$id);
DB::delete('partnerzy')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/slider");		
}



public function action_slider_edit($id) {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Slider - Edycja';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT * FROM slider WHERE id="'.$id.'"')->as_object()->execute()->as_array();
	$this->template->content = View::factory('admin/sliders/slider_edit')->bind('slider',$query);
	echo $this->template;
	
	$data = Request::current()->post();
	
	if(empty($data)) {} else {
		DB::update('slider')->set(array('title' => $data['title'] ,  'text' => $data['text'] ,  'link' => $data['link'] ))->where('id', '=', $id)->execute();
		$this->log->debug("Wyedytowano Wpis Slider Na Głównej: <b>{$data['title']}</b>",'Slider Główna');
		Request::instance()->redirect("/admin/partnerzy_edit/".$id);
	}
	 
	
	} else {
		Request::instance()->redirect("/admin");
	}
}

//WYKUP

public function action_wykup() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Zamówienia';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT * FROM zapisz_sie_data')->as_object()->execute()->as_array();
	$query_a1 = DB::query(Database::SELECT, 'SELECT * FROM zapisz_sie')->as_object()->execute()->as_array();
	$query_a2 = DB::query(Database::SELECT, 'SELECT * FROM zapisz_status')->as_object()->execute()->as_array();
	$this->template->content = View::factory('admin/wykup/index')->bind("zamowienia",$query)->bind("kategorie",$query_a1)->bind("status",$query_a2);
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}


public function action_wykup_ajax($id) {
		$query = DB::query(Database::SELECT, 'SELECT * FROM zapisz_sie_data WHERE id='.$id)->as_object()->execute()->as_array();
		
		if($query[0]->status == 0) {
				DB::update('zapisz_sie_data')->set(array('status' => 5))->where('id', '=', $id)->execute();
		$email = Email::instance();
		$email->to("email2");
		$email->od($query[0]->email);
		$email->subject("Zamówienie Kursu/Szkolenia Zostało Potwierdzone");
		$email->body('Imie: '.$query[0]->imie.' <Br> Nazwisko: '.$query[0]->nazwisko. '<br> E-mail: '.$query[0]->email. '<br> Telefon: '.$query[0]->telefon. '<br> Dnia: '.$query[0]->data. '<br> Godzina: '.$query[0]->godzina);
		$email->send();
		} else {
				DB::update('zapisz_sie_data')->set(array('status' => 0))->where('id', '=', $id)->execute();
		}
		
		Request::instance()->redirect("/admin/wykup");
		
}

#############################################

public function action_settings() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Ustawienia';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$this->template->content = View::factory('admin/settings/index');
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}


//

public function action_system() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - System';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$this->template->content = View::factory('admin/settings/system');
	
	//KONCZE LADOWAĆ
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_logs() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Logi Systemowe';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();	
	$this->template->content = View::factory('admin/logs/index');
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_loga() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Loga Pod Stron';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();
	//LADUJE DANE Z MYSQL 
	$query = DB::query(Database::SELECT, 'SELECT * FROM  `loga`')->execute()->as_array();

	$this->template->content = View::factory('admin/podstrony/loga')->bind('loga',$query)->bind("uri", $uris);
	
	
	//KONCZE LADOWAĆ
	echo $this->template;
	$data = Request::current()->post();

	if(empty($_FILES)) {} else {	
	$filename = Upload::save($_FILES, APPPATH . 'uploads/loga');
	$logaa = array("src" => 'uploads/loga/'.$filename);
	DB::query(Database::INSERT, DB::insert('loga', array_keys($logaa))->values(array_values($logaa)))->execute();
	$this->log->info('Dodano Nowe Logo: '.$filename);
	Request::instance()->redirect("/admin/loga");
	}
	 
	
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_galleria() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Galleria';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();	
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->content = View::factory('admin/gallery/index')->bind("uri",$uris);
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_galkat() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Galleria / Kategorie';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();	
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->content = View::factory('admin/gallery/category')->bind("uri",$uris);
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_galfoto() {
	if ($this->auth->logged_in('admin')) {
	$this->template = View::factory('admin/page');
	$this->template->title = 'Panel Administracyjny - Galleria / Dodaj Zdjęcie';
	$this->template->uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->users = Auth::instance()->get_user();	
	$uris = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/admin/';
	$this->template->content = View::factory('admin/gallery/addfoto')->bind("uri",$uris);
	echo $this->template;
	} else {
		Request::instance()->redirect("/admin");
	}
}

public function action_galkatadd() {
	$data = Request::current()->post();
	if(empty($data)) {
		Request::instance()->redirect("/admin/galkat");
	} else {	
	DB::query(Database::INSERT, DB::insert('gal_cat', array_keys($data))->values(array_values($data)))->execute();
	$this->log->info('Dodano Nową Kategorie: '.$data['title']);
	}	
}

public function action_get_galkat() {
	$query = DB::query(Database::SELECT, 'SELECT * FROM gal_cat')->as_object()->execute()->as_array();
	echo '<table class="table">
										<thead>
											<tr>
                                            <th style="width:40px;"></th>
												<th>Id</th>
												<th>Tytuł</th>
												<th></th>
											</tr>
										</thead>
										<tbody id="sortable">';
                                        
										foreach($query as $foto) {
                                        echo '<tr>
                                            <td style="width:40px;"></td>
												<td>'.$foto->id.'</td>
												<td>'.$foto->title.'</td>
												<td><a title="Delete" href="#demoModal'.$foto->id.'" data-backdrop="static" data-toggle="modal" oldtitle="New messages" aria-describedby="ui-tooltip-17"><i class="icon-trash"></i></a></td>
											</tr>'; 
											
											echo '<!-- USUN modal -->
								<div class="modal fade hide modal-info" id="demoModal'.$foto->id.'">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">×</button>
										<h3>Informacja!!</h3>
									</div>
									<div class="modal-body">
										<p>Potwierdzenie Usunięcia: <b>'.$foto->title.'</b></p>
										<p>Czy jesteś pewien że chcesz usunąc ten wpis ??</p>
									</div>
									<div class="modal-footer">
										<a href="#" class="btn btn-alt" data-dismiss="modal">Anuluj Usuwanie</a>
										<a href="/admin/gal_delete/'.$foto->id.'" class="btn btn-alt">Potwierdzam Usunięcie</a>
									</div>
								</div>
								<!-- /USUN modal -->';                                      
										}
										
                                        echo '</tbody>
                                        
                                        </table>';
}

public function action_gal_delete($id) {
$this->log->warning('Usunięto Kategorie Galleri o id: '.$id);
DB::delete('gal_cat')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/galkat");	
}

public function action_ajax_seo() {
$url = $_POST['url'];
$suffix = $_POST['suffix'];
$a = array('/(ą|á|â|ã|ä|å|æ)/','/(ę|é|ê|ë)/','/(ł|í|î|ï)/','/(ó|ò|ó|ô|õ|ö|ø)/','/(ż|ź)/','/ć/','/þ/','/ń/','/ś/','/(ý|ÿ)/','/(=|\+|\/|\\\|\.|\'|\_|\\n| |\(|\))/','/[^a-z_ -]/s','/-{2,}/s','/([^a-z]*)([a-z-]*)([^a-z])/');
$b = array('a','e','i','o','u','c','d','n','s','y','-','','-',"$2");
echo '/show/'.trim(preg_replace($a, $b, strtolower($url)),'-');	
die();
}

public function action_ajax_seo1() {
$url = $_POST['url'];
$suffix = $_POST['suffix'];
$a = array('/(ą|á|â|ã|ä|å|æ)/','/(ę|é|ê|ë)/','/(ł|í|î|ï)/','/(ó|ò|ó|ô|õ|ö|ø)/','/(ż|ź)/','/ć/','/þ/','/ń/','/ś/','/(ý|ÿ)/','/(=|\+|\/|\\\|\.|\'|\_|\\n| |\(|\))/','/[^a-z_ -]/s','/-{2,}/s','/([^a-z]*)([a-z-]*)([^a-z])/');
$b = array('a','e','i','o','u','c','d','n','s','y','-','','-',"$2");
echo '/promocje/'.trim(preg_replace($a, $b, strtolower($url)),'-');	
die();
}

public function action_loga_delete($id) {
$this->log->warning('Usunięto Logo o id: '.$id);
DB::delete('loga')->where('id', '=', $id)->execute();
Request::instance()->redirect("/admin/loga");	
}


public function action_login() {
	$this->auth->login(Request::instance()->post('username'), Auth::instance()->hash_password(Request::instance()->post('password')));
	if ($this->auth->logged_in('admin')) {
	Request::instance()->redirect("/admin");
	} else {
	Request::instance()->redirect("/admin");
	}
}


public function action_logout() {
	$this->auth->logout(true);
	Request::instance()->redirect("/admin");	
}

}
?>