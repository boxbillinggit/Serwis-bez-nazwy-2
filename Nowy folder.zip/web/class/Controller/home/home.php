<?php

class Controller_Home_Home extends Controller  {

	public function __construct() {
	$this->session = Session::instance();
    $this->auth = Auth::instance();
	Webcms::load(SYSPATH.'class/Constant.php');		
	}

	public $template = 'home/page';

	public function before()
    {
		$this->log = new Logs ( $_SERVER['DOCUMENT_ROOT']."/system/logs/log.csv" ,';' );
		$this->template = View::factory('home/page')->bind('uris',$this->url);
	//SLIDER
	$this->all = DB::query(Database::SELECT, 'SELECT * FROM slider')->execute()->as_array();
	//KONIEC

	//MENU
	$this->menu = DB::query(Database::SELECT, 'SELECT * FROM menu WHERE top=1 AND sub_id=0')->execute()->as_array();
	
	$this->news_sport = DB::query(Database::SELECT, 'SELECT * FROM news WHERE active=1 AND cat=2 Order by id DESC LIMIT 10')->execute()->as_array();
	$this->news_technology = DB::query(Database::SELECT, 'SELECT * FROM news WHERE active=1 AND cat=3 Order by id DESC LIMIT 10')->execute()->as_array();
	
	//KONIEC
	$this->banner = "images/head-img1.jpg";
	$this->url = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/home/';
    }

	public function get_title($name) {
		$tit = DB::query(Database::SELECT, 'SELECT * FROM configuration WHERE klucz="'.$name.'"')->execute()->as_array();
		$get = $tit[0]['wartosc'];
		return $get;
	}
	
	public function action_index() {

	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	
	 //echo 'Page -> ' . $this->request->param('page');
         
        $count = ORM::factory('news')->count_all();

         
        $pagination = Pagination::factory(array(
            'total_items' => $count,
        ));
         
        $posts = ORM::factory('news')->where("cat","=","1")->order_by('id', 'DESC')
                ->limit($pagination->items_per_page)
                ->offset($pagination->offset)
                ->find_all();

	
	$this->news = DB::query(Database::SELECT, 'SELECT * FROM news WHERE active=1 AND cat=1 Order by id DESC LIMIT 3')->execute()->as_array();
	$this->news_swiat = DB::query(Database::SELECT, 'SELECT * FROM news WHERE active=1 AND cat=4 Order by id DESC LIMIT 3')->execute()->as_array();
	$this->slider_news = DB::query(Database::SELECT, 'SELECT * FROM news WHERE active=1 AND cat=5 Order by id DESC LIMIT 6')->execute()->as_array();
	$this->partnerzy = DB::query(Database::SELECT, 'SELECT * FROM partnerzy')->execute()->as_array();
	$this->promocje = DB::query(Database::SELECT, 'SELECT * FROM promocje WHERE active=1')->execute()->as_array();
	$this->last_comments = DB::query(Database::SELECT, 'SELECT * FROM cms_comments LEFT JOIN cms ON cms.id=seo_id')->execute()->as_array();
	$this->user = DB::query(Database::SELECT, 'SELECT * FROM users ORDER BY id DESC LIMIT 3')->execute()->as_array();
	$this->calendar = DB::query(Database::SELECT, 'SELECT * FROM calendar')->execute()->as_array();
	
	$title = $this->get_title("SITE_TITLE");
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('body',$this->bodys)->bind('menus',$this->menu);
	$this->template->slider = View::factory('home/slider')->bind('slider',$this->all)->bind('uris',$this->url)->bind('all',$this->slider_news);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
	$this->template->content = View::factory('home/content_home')->bind('news',$posts)->bind("pagination",$pagination)->bind('banner',$this->banner)->bind('uris',$this->url)->bind('usersa',$this->user)->bind('promocje',$this->promocje)->bind('last_comments',$this->last_comments)->bind('partnerzy',$this->partnerzy)->bind("swiat",$this->news_swiat)->bind("kalendarz",$this->calendar);
	echo $this->template;
	}
	
	
	public function action_register() {

	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	
	$title = 'Abjlanette.pl - Rejestracja';
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('body',$this->bodys)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
	$this->template->content = View::factory('home/content/register')->bind('uris',$this->url);
	echo $this->template;
	}
	
	public function action_register_add() {
		if(empty($_POST)) { 
		  echo 'Brak Wprowadzonych Danych.';
		} else {

	$data = Request::current()->post();
try
{
			$client = ORM::factory('user');
            $client->email = $data['email'];
            $client->username = $data['username'];
            $client->password = $data['password'];
			$client->name = $data['imie'];
			$client->sex = $data['sex'];
			$client->signature = $data['sygnatura'];
            $client->save();
			$role = ORM::factory('role','1');
			$role_user = ORM::factory('role','3');
			$client->add('roles',$role);
			$client->add('roles',$role_user);
			$client->save();
			echo 'Rejestracja Zakończona Powodzeniem.';
}
catch (ORM_Validation_Exception $e)
{
	$errors = $e->errors();
	var_dump($errors);
}
		}
	die();	
	}
	
	###################### POKAŻ + DODAJ + POBIERZ
	public function action_news($id = null) {
		if(empty($id)) {
			Request::instance()->redirect("/");
		} else {
		
	$this->bodys = 'page2';
	$this->news = DB::query(Database::SELECT, 'SELECT * FROM news WHERE id="'.$id.'" AND active=1')->as_object()->execute()->as_array();
	if(empty($this->news[0]->title)){ $this->title = 'Brak Wpisu'; } else { $this->title = $this->news[0]->title; }
	$this->template->headers = View::factory('home/header')->bind('title',$this->title)->bind('uris',$this->url)->bind('body',$this->bodys)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
	$this->template->content = View::factory('home/show.news')->bind('news',$this->news)->bind('uris',$this->url);
	echo $this->template;
		}
	}
	
	
	public function action_show($args) {
		//$this->request->param('id','value is null');  
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	
	$this->cms = DB::query(Database::SELECT, 'SELECT * FROM cms WHERE seo="/show/'.$args.'" AND active=1')->as_object()->execute()->as_array();
	$this->comments = DB::query(Database::SELECT, 'SELECT * FROM cms_comments where seo_id="'.$this->cms[0]->id.'"')->as_object()->execute()->as_array();
	if(empty($this->cms[0]->title)){ $this->title = 'Brak Wpisu'; } else { $this->title = $this->cms[0]->title; }
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$this->title)->bind('uris',$this->url)->bind('body',$this->bodys)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
	$this->template->content = View::factory('home/content/show')->bind('cms',$this->cms)->bind('uris',$this->url)->bind('comments',$this->comments);
	echo $this->template;
	}
	
	public function action_show_send() {
	$data = Request::current()->post();
	$address = $data['address'];
	unset($data['address']);
	if(empty($data)) {
		Request::instance()->redirect("/");
	} else {	
	DB::query(Database::INSERT, DB::insert('cms_comments', array_keys($data))->values(array_values($data)))->execute();
	$this->log->info('Dodano Nowy Komentarz: '.$data['name']);
	echo '1';
	}
	die();	
	}
	
	public function action_show_get_rate() {
	$this->data = Request::current()->post();
	$this->rate_all = @DB::query(Database::SELECT, 'SELECT * FROM cms_rating where seo_id="'.$this->data['seo_id'].'" ORDER BY id DESC')->as_object()->execute()->as_array();
	$this->rate_sr = @DB::query(Database::SELECT, 'SELECT avg(ocena) as il FROM cms_rating where seo_id="'.$this->data['seo_id'].'"')->as_object()->execute()->as_array();

	if(empty($this->rate_all)) {
		$this->get = array(
		"ocena" => 0,
		"srednia_ocena" => 0,
		"ocen" => 0,
		);
	} else {
	    $this->get = array(
		"ocena" => $this->rate_all[0]->ocena,
		"srednia_ocena" => number_format($this->rate_sr[0]->il,1),
		"ocen" => count($this->rate_all),
		);	
	}
		
		echo json_encode($this->get);
		die();
		
	}
	
	public function action_show_add_rate() {
	$data = Request::current()->post();
	$this->rate_all = @DB::query(Database::SELECT, 'SELECT * FROM cms_rating where seo_id="'.$data['seo_id'].'" AND ip="'.$_SERVER['REMOTE_ADDR'].'" ORDER BY id DESC')->as_object()->execute()->as_array();
	if(empty($this->rate_all)) {
	if(empty($data)) {
		Request::instance()->redirect("/");
	} else {	
	$ip = $_SERVER['REMOTE_ADDR'];
	$dane = array("ocena" => $data['ocena'], "ip" => $ip, "seo_id" => $data['seo_id']);
	DB::query(Database::INSERT, DB::insert('cms_rating', array_keys($dane))->values(array_values($dane)))->execute();
	$this->log->info('Dodano Nową ocene: '.$data['ocena']); 
	}
	} else {
		echo '1';
	}
	die();	
	}
	
	### KONIEC POBIERANIA + WYSWIETLANIA
	
	
	
	
	///NIE AKTUALNE

	public function action_kontakt() {
		$params1 = @Request::instance()->param('param1');
		$params2 = @Request::instance()->param('param2');
	if(empty($params1) || empty($params2)) {
	$title = $this->get_title('SITE_KONTAKT_TITLE');
	$this->bodys = 'page6';
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('body',$this->bodys)->bind('menus',$this->menu);;
	$this->template->menu = View::factory('home/menu')->bind('menu',$this->menu);
	$this->template->slider = '<div style="margin-top:38px;"></div>';
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
	$this->template->content = View::factory('home/kontakt')->bind('news',$this->news)->bind('banner',$this->banner)->bind('uris',$this->url);
	echo $this->template;
	} else {
		Request::instance()->redirect("/kontakt");
	}
	
	}

	public function action_promocje($args) {
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$check  = DB::query(Database::SELECT, 'SELECT * FROM promocje WHERE seo="'.$args.'" AND active=1')->as_object()->execute()->as_array();
	
	if(empty($check)) {
		Request::instance()->redirect("/");
		} else {
	$this->cms = DB::query(Database::SELECT, 'SELECT * FROM promocje WHERE seo="'.$args.'" AND active=1')->as_object()->execute()->as_array();
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$this->title)->bind('uris',$this->url)->bind('body',$this->bodys)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
	$this->template->content = View::factory('home/content/show_promotion')->bind('cms',$this->cms)->bind('uris',$this->url);
	echo $this->template;
	
	
	}
	
	}

	
	public function action_galeria()
	{			
		// echo Request::instance()->param('param1');
		
		$fotki = Request::instance()->param('param2');

		if (empty($fotki))
		{
			$categories = DB::query(Database::SELECT, 'SELECT * FROM galeria_categories WHERE category_id=1')->execute()->as_array();
		}
		else
		{
			$categories = array();
			$foto_one = '';
		}
		
		if(empty($fotki)) {
		$zdjecia = array();
		} else {
		$zdjecia = DB::query(Database::SELECT, 'SELECT * FROM galeria WHERE cat_id='.$fotki)->execute()->as_array();
		}
	//	$categories = DB::query(Database::SELECT, 'SELECT * FROM galeria_categories')->execute()->as_array();			
	
		$this->bodys = 'propage';
		$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('body',$this->bodys);
		$this->template->menu = View::factory('home/menu')->bind('menu',$this->menu);
		$this->template->slider = '<div style="margin-top:38px; color:white;"><h1></h1></div>';
		$this->template->footer = View::factory('home/footer')->bind('uris',$this->url)->bind('news_sport',$this->news_sport)->bind('news_technology',$this->news_technology);
		$this->template->content = View::factory('home/galeria')->bind('news',$this->news)->bind('menus',$this->menu_right)->bind('banner',$this->banner)->bind('uris',$this->url)->bind('zdjecia', $zdjecia)->bind('categories', $categories);
		echo $this->template;
	}
	
	public function action_send_mail() {
							$email = Email::instance();
							
							if($_POST['topic'] == 'Błąd Na Stronie') {
								$email->to("email2");
							} else {
								$email->to("email1");
							}
							$email->od($_POST['email']);
							$email->subject($_POST['topic']);
							$email->body($_POST['text'].' <Br> Wiadomość Od: '.$_POST['email']. '<br> Imie: '.$_POST['imie']);
							$email->send();	
							echo 'Wiadomość została wysłana, Prośimy czekać na kontakt z naszej strony.';
							exit();
	}

}





?>