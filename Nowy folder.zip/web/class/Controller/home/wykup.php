<?php

class Controller_home_wykup extends Controller  {

	public function __construct() {
	$this->session = Session::instance();
    $this->auth = Auth::instance();
	Webcms::load(SYSPATH.'class/Constant.php');		
	}

	public $template = 'home/page';

	public function before()
    {
		$this->log = new Logs ( $_SERVER['DOCUMENT_ROOT']."/system/logs/log.csv" ,';' );
		$this->template = View::factory('home/page')->bind('uris',$this->url);

	//MENU
	$this->menu = DB::query(Database::SELECT, 'SELECT * FROM menu WHERE top=1 AND sub_id=0')->execute()->as_array();
	
	//KONIEC
	$this->url = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/home/';
    }

	public function get_title($name) {
		$tit = DB::query(Database::SELECT, 'SELECT * FROM configuration WHERE klucz="'.$name.'"')->execute()->as_array();
		$get = $tit[0]['wartosc'];
		return $get;
	}
	
	public function action_index() {
	
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$this->typ = DB::query(Database::SELECT, 'SELECT * FROM zapisz_sie WHERE active=1')->as_object()->execute()->as_array();
	$title = $this->get_title("SITE_WYKUP");
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url);
	$this->template->content = View::factory('home/content/wykup')->bind('uris',$this->url)->bind('typ',$this->typ);
	echo $this->template;	
		
	}
	
	public function action_save() {
	$data = Request::current()->post() + array("status" => 0);
	if(empty($data['imie']) OR empty($data['nazwisko']) OR empty($data['typ']) OR empty($data['email'])) {
		Request::instance()->redirect("/");
	} else {
	DB::query(Database::INSERT, DB::insert('zapisz_sie_data', array_keys($data))->values(array_values($data)))->execute();
	
						$email = Email::instance();
							$email->to("email1");
							$email->od($_POST['email']);
							$email->subject("Zamówienie Kursu/Szkolenia");
							$email->body('Imie: '.$_POST['imie'].' <Br> Nazwisko: '.$_POST['nazwisko']. '<br> E-mail: '.$_POST['email']. '<br> Telefon: '.$_POST['telefon']. '<br> Dnia: '.$_POST['data']. '<br> Godzina: '.$_POST['godzina']);
							$email->send();
	
	$this->log->info('Zapisano Zamówienie: '.$data['imie']); 
	}
	
	die();	
	}
	
}
	
?>