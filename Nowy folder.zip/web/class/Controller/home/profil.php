<?php

class Controller_home_profil extends Controller  {

	public function __construct() {
	$this->session = Session::instance();
    $this->auth = Auth::instance();
	Webcms::load(SYSPATH.'class/Constant.php');		
	}

	public $template = 'home/page';

	public function before()
    {
		$this->log = new Logs ( $_SERVER['DOCUMENT_ROOT']."/system/logs/log.csv" ,';' );
		$this->template = View::factory('home/page')->bind('uris',$this->url);

	//MENU
	$this->menu = DB::query(Database::SELECT, 'SELECT * FROM menu WHERE top=1 AND sub_id=0')->execute()->as_array();
	
	//KONIEC
	$this->url = 'http://'.$_SERVER['HTTP_HOST'].'/web/view/home/';
    }

	public function get_title($name) {
		$tit = DB::query(Database::SELECT, 'SELECT * FROM configuration WHERE klucz="'.$name.'"')->execute()->as_array();
		$get = $tit[0]['wartosc'];
		return $get;
	}
	
	public function action_index($id = null) {
	
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$title = $this->get_title("SITE_PROFIL");
	$this->bodys = 'page1';
	
	$ta = Auth::instance()->get_user();
	
	if(empty($id)) {
	
		$ids = $ta->id;

	} else {
	$ids = $id;
	}
	
	
		
		$this->usera = DB::query(Database::SELECT, 'SELECT * FROM users WHERE id="'.$ids.'"')->execute()->as_array();
		$this->comments = DB::query(Database::SELECT, 'SELECT * FROM cms_comments CC LEFT JOIN cms ON cms.id = CC.seo_id where userid="'.$ids.'"')->as_object()->execute()->as_array();
/*	if(empty($id)) {
	$this->usera = DB::query(Database::SELECT, 'SELECT * FROM users WHERE username="'.$id.'"')->execute()->as_array();
	} else {
	$this->usera = DB::query(Database::SELECT, 'SELECT * FROM users')->execute()->as_array();	
	}*/
	$this->template->users = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url);
	$this->template->content = View::factory('home/content/profil')->bind('uris',$this->url)->bind('userss',$this->usera)->bind('komentarze',$this->comments);
	echo $this->template;	
		
	}
	
	public function action_settings() {
	if ($this->auth->logged_in('user')) {
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$title = $this->get_title("SITE_PROFIL_SETTINGS");
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->usera = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url);
	$this->template->content = View::factory('home/content/profil_settings')->bind('uris',$this->url)->bind('userss',$this->usera);
	echo $this->template;	
	} else {
		Request::instance()->redirect("/login");
	}
	
	}
	
	public function action_order() {
	if ($this->auth->logged_in('user')) {
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$title = "Zamówienia";
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->usera = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url);
	$this->template->content = View::factory('home/content/profil_order')->bind('uris',$this->url)->bind('userss',$this->usera);
	echo $this->template;	
	} else {
		Request::instance()->redirect("/login");
	}
	
	}
	
	
		public function action_car() {
	if ($this->auth->logged_in('user')) {
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$title = "Twoje Auto";
	$this->bodys = 'page1';
	$this->template->users = Auth::instance()->get_user();
	$this->usera = Auth::instance()->get_user();
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url);
	$this->template->content = View::factory('home/content/profil_car')->bind('uris',$this->url)->bind('userss',$this->usera);
	echo $this->template;	
	} else {
		Request::instance()->redirect("/login");
	}
	
	}
	
	
	public function action_dashboard() {
	if ($this->auth->logged_in('user')) {
	$this->log->info('Otwieram Controller ' . Request::instance()->controller .' AKCJA '. Request::instance()->action .' KATALOG '. Request::instance()->directory);
	$title = $this->get_title("SITE_PROFIL_DASHBOARD");
	$this->bodys = 'page1';
	$this->template->headers = View::factory('home/header')->bind('title',$title)->bind('uris',$this->url)->bind('menus',$this->menu);
	$this->template->footer = View::factory('home/footer')->bind('uris',$this->url);
	$this->template->content = View::factory('home/content/profil_dashboard')->bind('uris',$this->url);
	echo $this->template;	
	} else {
		Request::instance()->redirect("/login");
	}	
	}
	
	
}

?>