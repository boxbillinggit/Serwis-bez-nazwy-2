<?php 



class Controller_Error_error extends Controller {

	

	public function __construct()
	{
		Webcms::load(SYSPATH.'class/Exception.php');
		$this->request = Request::instance();
    }

	

	public function before()  {  

		//MENU
		$this->db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE); 
		$this->db->connect();
		$this->db->query('SET CHARSET utf8');

		raintpl::configure("base_url", null );
		raintpl::configure("tpl_dir", "templates/" );
		raintpl::configure("cache_dir", $_SERVER['DOCUMENT_ROOT']."/cache/" );
		//initialize a Rain TPL object
		$this->tpl = new RainTPL;
	}

	

	public function after() {}

	

	public function action_brak() {
pr($_SESSION); die();			$this->template = View::factory('Webcms/error');
			$class   = get_class($e);
			$code    = $e->getCode();
			$message = $e->getMessage();
			$file    = $e->getFile();
			$line    = $e->getLine();
			$trace   = $e->getTrace();
			$this->template->type = 'Error';
			$this->template->code = $code;
			$this->template->message = $message;
			$this->template->file = $file;
			$this->template->line = $line;
			$this->template->trace = $trace;
			echo $this->template;
			
		
	/*$this->template = View::factory('Webcms/error');
	$this->template->type = 'Error';
	$this->template->code = '404';
	$this->template->message = 'Nie odnaleziono Pliku';
	$this->template->file = Request::instance()->controller;
	$this->template->line = 0;
	$this->template->trace = array();
	echo $this->template; */
	
	/*	$var = array(
					"version"	=> "3.0 Alpha",
					"url"       => "",
					"title"     => "ERROR 404", 
				);
	$this->tpl->assign( $var );
	echo $this->tpl->draw( "theme1/error" ); */
	}


} 



?>