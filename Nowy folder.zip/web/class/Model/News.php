<?php
class Model_News extends ORM {
    protected $_table_name = 'news';
}
?>